import axios from "axios";
import { useState } from "react";

const useCloudinaryUpload = (type: string) => {  // store images and videos to cloudinary
    const [media, setMedia] = useState<string[]>([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
  
    const uploadMedia = async (files:File[]) => {
      const uploadPromises = [];
      setLoading(true);
      setError(null);

      console.log(type, files);
  
      for (let file of files) {
        const data = new FormData();
        data.append('file', file);
        data.append('upload_preset', 'angular_ott'); // replace with your upload preset
        data.append('cloud_name', 'dmal60cmf');

        const uploadPromise = axios.post(`https://api.cloudinary.com/v1_1/dmal60cmf/${type}/upload`, data, {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        });
        uploadPromises.push(uploadPromise);
      }
  
      try {
        const responses = await Promise.all(uploadPromises);
        const uploadedMedia = responses.map(res => res.data.secure_url);
        setMedia(uploadedMedia);
        return uploadedMedia;
      } catch (err) {
        setError(err);
      } finally {
        setLoading(false);
      }
    };
  
    return { media, loading, error, uploadMedia };
  };
  
  export default useCloudinaryUpload;