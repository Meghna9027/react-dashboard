// import { Icon } from '@iconify/react';
import { Box, Button, Grid, IconButton } from '@mui/material';
import React, { Dispatch, SetStateAction, useState } from 'react';
import { VideoData } from 'src/interfaces/interfaces';

interface InputDetailsProps {
  shorts: File[];
  setShorts: Dispatch<SetStateAction<File[]>>;
}

export default function InputVideos({ shorts, setShorts }: InputDetailsProps) {
  const handleOnAddVideo = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return;
    const files = Array.from(e.target.files);
    setShorts((prevVideos: File[]) => [...prevVideos, ...files]);
    e.target.value = '';
  };

  const handleOnRemoveVideo = (index: number) => {
    setShorts((prevVideos: File[]) => prevVideos.filter((_, i) => i !== index));
  };

  return (
    <>
      <Grid container spacing={2}>
        {shorts.map((video, index) => (
          <Grid item xs={4} key={index} style={{ position: 'relative' }}>
            <IconButton
              aria-label="delete video"
              style={{ position: 'absolute', top: 10, right: 10, color: '#aaa' }}
              onClick={() => handleOnRemoveVideo(index)}
            >
              CLOSE
              {/* <Icon icon={cancelIcon} /> */}
            </IconButton>
            <video
              src={URL.createObjectURL(video)}
              controls
              style={{ width: '100%', height: '100%', objectFit: 'contain' }}
            />
          </Grid>
        ))}
      </Grid>
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          width: '100%',
        }}
      >
        <label htmlFor="upload-button">
          <Button variant="contained" component="span" style={{ marginTop: 16 }}>
            Upload Videos
          </Button>
        </label>
      </Box>
      <input
        id="upload-button"
        type="file"
        multiple
        accept="video/*"
        onChange={handleOnAddVideo}
        style={{ display: 'none' }}
      />
    </>
  );
}
