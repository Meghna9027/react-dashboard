import axios from 'axios';
import React from 'react';
import { VideoData } from 'src/interfaces/interfaces';

const UPLOAD_VIDEO_URL = 'http://localhost:8765/creator-service/creator/upload-video';

export const postUploadVideo = async (
  newVideo: VideoData
): Promise<{
  success: boolean;
  message?: string;
}> => {
  try {
    const response = await axios.post(UPLOAD_VIDEO_URL, newVideo, {
      headers: {
        'Content-Type': 'application/json',
      },
      withCredentials: true
    });

    console.log(response);

    if (response.status === 200) {
      return { success: true };
    }

    // Handle other status codes
    return { success: false, message: 'Upload Video failed' };
  } catch (error) {
    console.error('Error during Uploading Video:', error);

    // Handle error messages from Spring Security
    return { success: false, message: error.response?.data?.message || 'An error occurred' };
  }
};
