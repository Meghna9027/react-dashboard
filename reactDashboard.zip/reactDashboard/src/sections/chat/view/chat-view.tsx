import React from 'react';


export function ChatView() {
  return(
    <div>
      <h1>Chat View</h1>
    </div>
  )
}