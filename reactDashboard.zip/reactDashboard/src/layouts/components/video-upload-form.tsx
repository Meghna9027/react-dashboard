import { LoadingButton } from '@mui/lab';
import { Box, Typography } from '@mui/material';
import { Ref, useCallback, useEffect, useRef, useState } from 'react';
import InputDetails from './upload-video/input-details';
import InputImages from './upload-video/input-images';
import InputVideos from './upload-video/input-videos';
import InputCast from './upload-video/input-cast';
import { toast, ToastContainer } from 'react-toastify';
import { postUploadVideo } from 'src/api/post-upload-video';
import { NewCastProps, VideoData } from 'src/interfaces/interfaces';
import useCloudinaryUpload from 'src/hooks/useCloudinaryUpload';

export default function VideoUploadForm() {
  const [step, setStep] = useState(1);

  const [videoDetails, setVideoDetails] = useState<VideoData>();
  const [thumbnail, setThumbnail] = useState<File[]>([]);
  const [video, setVideo] = useState<File[]>([]);
  const [castImgs, setCastImgs] = useState<File[]>([]);

  const [images, setImages] = useState<File[]>([]);
  const [shorts, setShorts] = useState<File[]>([]);
  const [isNextDisabled, setIsNextDisabled] = useState(true); // State to control "Next" button

  const [cast, setCast] = useState<NewCastProps[]>([
    { name: '', character: '', profilePath: null, popularity: 0.0 },
  ]);

  const { media: media1, uploadMedia: uploadImages } = useCloudinaryUpload('image');
  const { media: media2, uploadMedia: uploadVideos } = useCloudinaryUpload('video');

  const handleMediaUpload = async (type: String, media: File[]) => {
    if (type === 'image') {
      const response = await uploadImages(media);
      if (response) {
        console.log(response);
        return response;
      } else {
        toast.error('Image upload failed');
      }
    } else if (type === 'video') {
      const response = await uploadVideos(media);
      if (response) {
        console.log(response);
        return response;
      } else {
        toast.error('Video upload failed');
      }
    }
  };

  const uploadVideo = async () => {
    console.log('image', thumbnail);
    const thumbnailResponses = await handleMediaUpload('image', thumbnail); // thumbnail
    console.log('thumbnailResponses ', thumbnailResponses);
    if (thumbnailResponses?.length === 0) {
      toast.error('Thumbnail upload failed');
      return;
    }

    console.log('video', video);
    const videoResponses = await handleMediaUpload('video', video); // videoUrl
    console.log('videoResponses ', videoResponses);
    if (videoResponses?.length === 0) {
      toast.error('Video upload failed');
      return;
    }

    console.log('image', images);
    const imageResponses = await handleMediaUpload('image', images); // IMAGES
    console.log('imageResponses ', imageResponses);
    if (imageResponses?.length === 0) {
      toast.error('Image upload failed');
      return;
    }

    // Upload videos next
    console.log('video', shorts);
    const shortsResponses = await handleMediaUpload('video', shorts); // SHORTS
    console.log('shortsResponses ', shortsResponses);
    if (shortsResponses?.length === 0) {
      toast.error('Shorts upload failed');
      return;
    }

    console.log('image', castImgs);
    const castImgResponses = await handleMediaUpload('image', castImgs); // Cast ProfilePaths
    console.log('castImgResponses ', castImgResponses);
    if (castImgResponses?.length === 0) {
      toast.error('Cast Image upload failed');
      return;
    }

    const newVideoData = videoDetails;
    if (
      newVideoData != undefined &&
      thumbnailResponses != undefined &&
      videoResponses != undefined &&
      castImgResponses != undefined
    ) {
      newVideoData['posterPath'] = thumbnailResponses[0];
      newVideoData['videoUrl'] = videoResponses[0];
      newVideoData['images'] =
        imageResponses?.map((media) => {
          return { height: 100, width: 100, filePath: media };
        }) || [];
      newVideoData['shorts'] =
        shortsResponses?.map((media) => {
          return { name: '', shortKey: media, type: 'Trailer' };
        }) || [];
      newVideoData['cast'] = cast.map((c, i) => {
        return {
          name: c.name,
          profilePath: castImgResponses[i],
          characterr: c.character,
          popularity: +c.popularity,
        };
      });
    }

    console.log(newVideoData);

    setVideoDetails(newVideoData);

    console.log(videoDetails, media1, media2, cast);

    if (videoDetails) {
      const response = await postUploadVideo(videoDetails);

      if (response?.success) {
        toast.success("'Video upload successful!");
      } else {
        toast.error('Invalid id');
      }
    }
  };

  return (
    <>
      <Box gap={1.5} display="flex" flexDirection="column" alignItems="center" sx={{ mb: 5 }}>
        <Typography variant="h5">Upload Video</Typography>
      </Box>
      <ToastContainer />

      {step == 1 && (
        <InputDetails
          thumbnail={thumbnail}
          setThumbnail={setThumbnail}
          video={video}
          setVideo={setVideo}
          videoDetails={videoDetails as VideoData}
          setVideoDetails={setVideoDetails as React.Dispatch<React.SetStateAction<VideoData>>}
          setIsNextDisabled={setIsNextDisabled}
        />
      )}
      {step == 2 && (
        <InputImages
          multiple={true}
          images={images}
          setImages={setImages as React.Dispatch<React.SetStateAction<File[]>>}
        />
      )}
      {step == 3 && (
        <InputVideos
          shorts={shorts}
          setShorts={setShorts as React.Dispatch<React.SetStateAction<File[]>>}
        />
      )}
      {step == 4 && (
        <InputCast
          cast={cast}
          setCast={setCast as React.Dispatch<React.SetStateAction<NewCastProps[]>>}
          castImgs={castImgs}
          setCastImgs={setCastImgs as React.Dispatch<React.SetStateAction<File[]>>}
          setIsNextDisabled={setIsNextDisabled}
        />
      )}

      <Box display="flex" justifyContent="space-between">
        {step > 1 && (
          <LoadingButton
            // fullWidth
            size="large"
            type="submit"
            color="inherit"
            variant="contained"
            onClick={() => {
              setStep((p) => p - 1);
            }}
          >
            Back
          </LoadingButton>
        )}
        <LoadingButton
          // fullWidth
          size="large"
          type="submit"
          color="inherit"
          variant="contained"
          onClick={() => {
            if (step == 4) {
              uploadVideo();
            } else if (step < 4) setStep((p) => p + 1);
          }}
          disabled={isNextDisabled}
        >
          Next
        </LoadingButton>
      </Box>
    </>
  );
}
