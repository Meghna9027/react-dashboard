import { useState } from 'react';
import {
  Box,
  Typography,
  Card,
  CardContent,
  Grid,
  Button,
  Modal,
  Tooltip,
  IconButton,
  List,
  ListItem,
  ListItemAvatar,
  Avatar,
  ListItemText,
} from '@mui/material';
import { _posts, _postTitles } from 'src/_mock';
import FavoriteIcon from '@mui/icons-material/Favorite';
import VisibilityIcon from '@mui/icons-material/Visibility';
import CommentIcon from '@mui/icons-material/Comment';

// Sample video data (You can replace this with actual data)

const modalStyle = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: '80%',
  bgcolor: 'background.paper',
  border: '20px solid #fff',
  borderRadius: '20px',
  boxShadow: 24,
  maxHeight: 'calc(100vh - 100px)',
  overflowY: 'auto',
};

const initialVideoData = [
  {
    id: 1,
    title: 'Video 1',
    url: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    likes: 4,
    views: 2,
  },
  {
    id: 2,
    title: 'Video 2',
    url: 'https://www.youtube.com/embed/9bZkp7q19f0',
    likes: 0,
    views: 0,
  },
  {
    id: 3,
    title: 'Video 3',
    url: 'https://www.youtube.com/embed/tgbNymZ7vqY',
    likes: 0,
    views: 0,
  },
  {
    id: 4,
    title: 'Video 4',
    url: 'https://www.youtube.com/embed/uiOimjucxow',
    likes: 0,
    views: 0,
  },
  {
    id: 5,
    title: 'Video 5',
    url: 'https://www.youtube.com/embed/EMOEjA6UMsQ',
    likes: 0,
    views: 0,
  },
  {
    id: 6,
    title: 'Video 6',
    url: 'https://www.youtube.com/embed/Ua5AW2czRAE',
    likes: 0,
    views: 0,
  },
  {
    id: 7,
    title: 'Video 7',
    url: 'https://www.youtube.com/embed/WKbwopSXLWU',
    likes: 0,
    views: 0,
  },
  {
    id: 8,
    title: 'Video 8',
    url: 'https://www.youtube.com/embed/0YFENcrtc7M',
    likes: 0,
    views: 0,
  },
  {
    id: 9,
    title: 'Video 9',
    url: 'https://www.youtube.com/embed/Q8bKKn8gBVY',
    likes: 0,
    views: 0,
  },
  {
    id: 10,
    title: 'Video 10',
    url: 'https://www.youtube.com/embed/U_UjsT_RkI8',
    likes: 0,
    views: 0,
  },
  {
    id: 11,
    title: 'Video 11',
    url: 'https://www.youtube.com/embed/kzTWRX9Dhrg',
    likes: 0,
    views: 0,
  },
  {
    id: 12,
    title: 'Video 12',
    url: 'https://www.youtube.com/embed/bBvlfHU4nDI',
    likes: 0,
    views: 0,
  },
  {
    id: 13,
    title: 'Video 13',
    url: 'https://www.youtube.com/embed/DIJW7rWPkSw',
    likes: 0,
    views: 0,
  },
  {
    id: 14,
    title: 'Video 14',
    url: 'https://www.youtube.com/embed/6WLugDJYXmM',
    likes: 0,
    views: 0,
  },
  {
    id: 15,
    title: 'Video 15',
    url: 'https://www.youtube.com/embed/0KozfDYK1EU',
    likes: 0,
    views: 0,
  },
  {
    id: 16,
    title: 'Video 16',
    url: 'https://www.youtube.com/embed/osbSJ2Fr1nE',
    likes: 0,
    views: 0,
  },
  {
    id: 17,
    title: 'Video 17',
    url: 'https://www.youtube.com/embed/XgdY_s1LsZc',
    likes: 0,
    views: 0,
  },
  {
    id: 18,
    title: 'Video 18',
    url: 'https://www.youtube.com/embed/36oG0GKlVBs',
    likes: 0,
    views: 0,
  },
  {
    id: 19,
    title: 'Video 19',
    url: 'https://www.youtube.com/embed/cN1ouN1N70w',
    likes: 0,
    views: 0,
  },
  {
    id: 20,
    title: 'Video 20',
    url: 'https://www.youtube.com/embed/ninsb8n8cRE',
    likes: 0,
    views: 0,
  },
  {
    id: 21,
    title: 'Video 21',
    url: 'https://www.youtube.com/embed/IKEdWz8Y27I',
    likes: 0,
    views: 0,
  },
  {
    id: 22,
    title: 'Video 22',
    url: 'https://www.youtube.com/embed/o1tIvfplhHc',
    likes: 0,
    views: 0,
  },
  {
    id: 23,
    title: 'Video 23',
    url: 'https://www.youtube.com/embed/7k5gM4ClRRo',
    likes: 0,
    views: 0,
  },
];

export default function VideoDetailPage({
  videoUrl,
  videoTitle,
  videoDescription,
  videoCast,
  comments,
}: {
  videoUrl: string | null;
  videoTitle: string;
  videoDescription: string;
  videoCast: string;
  comments: { userName: string; profilePic: string; comment: string }[];
}) {
  // State to hold the currently selected video URL
  const [selectedVideo, setSelectedVideo] = useState<{
    id: number;
    title: string;
    url: string;
    likes: number;
    views: number;
  } | null>(null);
  const [videoData, setVideoData] = useState(initialVideoData);
  const [viewModalOpen, setViewModalOpen] = useState(false);
  const [commentModalOpen, setCommentModalOpen] = useState(false);

  const handleLike = (id: number) => {
    setVideoData((prevData) => {
      const updatedData = prevData.map((video) => {
        if (video.id === id) {
          return { ...video, likes: video.likes + 1 };
        }
        return video;
      });
      const updatedVideo = updatedData.find((video) => video.id === id);
      if (updatedVideo) {
        setSelectedVideo(updatedVideo); // Ensure selectedVideo is updated
      }
      return updatedData;
    });
  };

  const handleView = (id: number) => {
    const video = videoData.find((video) => video.id === id) || null;
    if (video) {
      setSelectedVideo(video);
      // Increment view count when the video is viewed
      setVideoData((prevData) =>
        prevData.map((v) => (v.id === id ? { ...v, views: v.views + 1 } : v))
      );
      setViewModalOpen(true);
    }
  };

  const handleComment = (id: number) => {
    const video = videoData.find((video) => video.id === id) || null;
    setSelectedVideo(video);
    setCommentModalOpen(true);
  };

  return (
    <Box sx={{ padding: 4 }}>
      {/* Video Title */}
      <Typography variant="h4" gutterBottom>
        Video Detail
      </Typography>

      {/* Modal to display the selected video */}
      {videoUrl && (
        <Box sx={{ position: 'relative', paddingTop: '56.25%', maxWidth: '100%' }}>
          <iframe
            width="100%"
            height="100%"
            src={videoUrl}
            frameBorder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
            title="Video"
            style={{ position: 'absolute', top: 0, left: 0 }}
          />
        </Box>
      )}
      <div
        style={{ color: 'primary.main', fontSize: '20px', fontWeight: 'bold', marginTop: '20px' }}
      >
        {videoTitle}
      </div>
      <Box sx={{ display: 'flex', justifyContent: 'space-around', mt: 2 }}>
        <Tooltip title="Like">
          <IconButton
            onClick={() => {
              if (selectedVideo) {
                handleLike(selectedVideo.id);
              }
            }}
            sx={{
              color: selectedVideo && selectedVideo.likes > 0 ? 'red' : 'grey',
              transition: 'color 0.3s',
            }}
          >
            <FavoriteIcon />
          </IconButton>
        </Tooltip>
        {/* View Button */}
        <Tooltip title="View Details">
          <IconButton
            onClick={() => {
              if (selectedVideo) {
                handleView(selectedVideo.id);
              }
            }}
          >
            <VisibilityIcon />
          </IconButton>
        </Tooltip>
        {/* Comment Button */}
        <Tooltip title="Add Comment">
          <IconButton
            onClick={() => {
              if (selectedVideo) {
                handleComment(selectedVideo.id);
              }
            }}
          >
            <CommentIcon />
          </IconButton>
        </Tooltip>
      </Box>
      <Typography variant="body2" sx={{ mt: 1 }}>
        <p>Likes: {selectedVideo?.likes}</p>
        <p>Views: {selectedVideo?.views}</p>
      </Typography>
      <Typography variant="body1" sx={{ mt: 2 }}>
        {videoDescription}
      </Typography>
      <Typography variant="body1" sx={{ mt: 2 }}>
        Cast: {videoCast}
      </Typography>
      <Typography variant="h6" sx={{ mb: 2, mt: 5 }}>
        Comments
      </Typography>
      <List>
        {comments.map((comment, index) => (
          <ListItem key={index} alignItems="flex-start">
            <ListItemAvatar>
              <Avatar src={comment.profilePic} alt={comment.userName} />
            </ListItemAvatar>
            <ListItemText
              primary={comment.userName}
              secondary={<Typography variant="body2">{comment.comment}</Typography>}
            />
          </ListItem>
        ))}
      </List>

      {/* <Modal open={viewModalOpen} onClose={() => setViewModalOpen(false)}>
        <Box sx={modalStyle}>
          <Typography variant="h5">Views for {selectedVideo?.title}</Typography>
          <Typography variant="body1">
            This video has been viewed {selectedVideo?.views} times.
          </Typography>
        </Box>
      </Modal> */}

      {/* Comment Modal */}
      {/* <Modal open={commentModalOpen} onClose={() => setCommentModalOpen(false)}>
        <Box sx={modalStyle}>
          <Typography variant="h5">Add a Comment for {selectedVideo?.title}</Typography>
          <Typography variant="body1">Feature under development!</Typography>
        </Box>
      </Modal> */}
    </Box>
  );
}
