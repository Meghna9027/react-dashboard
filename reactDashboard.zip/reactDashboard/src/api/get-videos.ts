import axios from 'axios';
import React from 'react'

const VIDEOS_URL = 'http://localhost:8765/creator-service/creator/';

export const getVideos = async(id:number) => {
  try {
    const API_URL = VIDEOS_URL + id + "/videos";
    
    const response = await axios.get(API_URL, {
      headers: {
        'Content-Type': 'application/json',
      },
      withCredentials: true,  
    });

    console.log(response);
    
    if (response.status === 200) {
      return { success: true };
    }

    // Handle other status codes
    return { success: false, message: 'Fetch Videos failed' };
  } catch (error) {
    console.error('Error during Fetching Videos:', error);

    // Handle error messages from Spring Security
    return { success: false, message: error.response?.data?.message || 'An error occurred' };
  }
}
