import axios from 'axios';

const CREATOR_LOGIN_URL = 'http://localhost:8765/creator-service/creator/login';

interface LoginCredentials {
  email: string;
  password: string;
}
export const postLogin = async (
  credentials: LoginCredentials
): Promise<{
  success: boolean;
  data?: any;
  message?: string;
}> => {
  try {
    
    const response = await axios.post(CREATOR_LOGIN_URL, credentials, {
      headers: {
        'Content-Type': 'application/json',
      },
    });
    
    console.log(response);

    if (response.status === 200 && response.data) {
      console.log(response.data);
      localStorage.setItem('creatorID', response.data);

      return { success: true, data: response.data };
    }

    return { success: false, message: 'Login failed' };
  } catch (error) {
    console.error('Error during login:', error);

    return { success: false, message: error.response?.data?.message || 'An error occurred' };
  }
};
