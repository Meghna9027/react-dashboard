import { Box, Button, TextField } from '@mui/material';
import React, { ChangeEvent, Dispatch, SetStateAction, useRef, useState } from 'react';
import InputImages from './input-images';
import { NewCastProps, VideoData } from 'src/interfaces/interfaces';
import { Avatar } from '@mui/material';
import { Stack } from '@mui/material';

interface InputDetailsProps {
  cast: NewCastProps[];
  setCast: Dispatch<SetStateAction<NewCastProps[]>>;
  castImgs: File[];
  setCastImgs: Dispatch<SetStateAction<File[]>>;
  setIsNextDisabled: Dispatch<SetStateAction<boolean>>;
}

export default function InputCast({
  cast,
  setCast,
  castImgs,
  setCastImgs,
  setIsNextDisabled,
}: InputDetailsProps) {
  const imgRefs = useRef<HTMLInputElement[]>([]);

  const handleClick = (index: number) => {
    if (imgRefs.current[index]) {
      imgRefs.current[index].click();
    }
  };

  console.log(cast);

  const handleImageChange = (event: ChangeEvent<HTMLInputElement>, index: number) => {
    const files = event.target.files;
    if (files && files[0]) {
      const img = Array.from(files);
      const newCastImgs = [...castImgs];
      newCastImgs[index] = img[0];
      setCastImgs(newCastImgs);

      const newCast = [...cast];
      newCast[index].profilePath = URL.createObjectURL(files[0]);
      setCast(newCast);
    }
  };

  const checkIfAllFieldsFilled = () => {
    const isFilled = cast.every((c) => c.name !== '' && c.character !== '' && c.popularity > 0);
    setIsNextDisabled(!isFilled); // Disable/Enable Next button based on the check
  };

  return (
    <Box display="flex" flexDirection="column" alignItems="flex-end">
      <Button
        variant="contained"
        component="span"
        style={{ marginTop: 10, marginBottom: 20 }}
        onClick={() => {
          // check if all previous cast detail is filled or not
          // if (cast[cast.length - 1].name != '' && cast[cast.length - 1].character != '') {
          const addCast = [...cast, { name: '', character: '', profilePath: '', popularity: 0.0 }];
          setCast(addCast);
          // }
        }}
      >
        Add Cast
      </Button>
      {cast.map((c, index) => {
        return (
          <Box display="flex" key={index}>
            <Stack
              width="100%"
              display="flex"
              direction="column"
              alignItems="center"
              spacing={2}
              sx={{ mb: 3 }}
            >
              <Avatar
                sx={{ width: 100, height: 100, cursor: 'pointer', border: '3px solid black' }}
                src={c?.profilePath || ''}
                onClick={() => handleClick(index)}
              />
              <input
                type="file"
                accept="image/*"
                onChange={(e) => {
                  handleImageChange(e, index);
                }}
                ref={(el) => (imgRefs.current[index] = el!)}
                hidden
              />
            </Stack>
            <Box>
              <TextField
                fullWidth
                name="name"
                label="Name"
                defaultValue={cast[index].name}
                required
                InputLabelProps={{ shrink: true }}
                sx={{ mb: 3 }}
                onChange={(e) => {
                  const updatedCast = cast;
                  updatedCast[index].name = e.target.value;
                  setCast(updatedCast);
                  checkIfAllFieldsFilled();
                }}
              />
              <TextField
                fullWidth
                name="character"
                label="Character"
                defaultValue={cast[index].character}
                required
                InputLabelProps={{ shrink: true }}
                sx={{ mb: 3 }}
                onChange={(e) => {
                  const updatedCast = cast;
                  updatedCast[index].character = e.target.value;
                  setCast(updatedCast);
                  checkIfAllFieldsFilled();
                }}
              />
              <TextField
                fullWidth
                name="populality"
                label="Populality"
                type="number"
                defaultValue={cast[index].popularity}
                InputLabelProps={{ shrink: true }}
                sx={{ mb: 3 }}
                onChange={(e) => {
                  const updatedCast = cast;
                  updatedCast[index].popularity = +e.target.value;
                  setCast(updatedCast);
                  checkIfAllFieldsFilled();
                }}
              />
            </Box>
          </Box>
        );
      })}
    </Box>
  );
}
