import axios from 'axios';
import React from 'react';

const CREATOR_SIGNUP_URL = 'http://localhost:8765/creator-service/creator/register';

interface SignUpCredentials {
  avatar: string;
  name: string;
  phone: number;
  age: number;
  gender: string;
  facebookId?: string;
  instagramId?: string;
  tweeterId?: string;
  imdbId?: string;
  email: string;
  password: string;
}

export const postSignup = async (
  credentials: SignUpCredentials
): Promise<{
  success: boolean;
  message?: string;
}> => {
  try {
    
    const response = await axios.post(CREATOR_SIGNUP_URL, credentials, {
      headers: {
        'Content-Type': 'application/json',
      },
    });

    console.log(response);
    
    if (response.status === 200) {
      return { success: true };
    }

    // Handle other status codes
    return { success: false, message: 'SignUp failed' };
  } catch (error) {
    console.error('Error during SignUp:', error);

    // Handle error messages from Spring Security
    return { success: false, message: error.response?.data?.message || 'An error occurred' };
  }
};
