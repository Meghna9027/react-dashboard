import { useState, useCallback, ChangeEvent, useRef } from 'react';

import Box from '@mui/material/Box';
import Link from '@mui/material/Link';
import Divider from '@mui/material/Divider';
import TextField from '@mui/material/TextField';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import LoadingButton from '@mui/lab/LoadingButton';
import InputAdornment from '@mui/material/InputAdornment';
import {
  Radio,
  FormLabel,
  RadioGroup,
  FormControl,
  FormControlLabel,
  Stack,
  Avatar,
  Button,
} from '@mui/material';

import { useRouter } from 'src/routes/hooks';

import { Iconify } from 'src/components/iconify';
import { RouterLink } from 'src/routes/components';
import { postSignup } from 'src/api/post-signup';
import { toast, ToastContainer } from 'react-toastify';

interface SignUpCredentials {
  avatar: string;
  name: string;
  phone: number;
  age: number;
  gender: string;
  facebookId?: string;
  instagramId?: string;
  tweeterId?: string;
  imdbId?: string;
  email: string;
  password: string;
}

export function SignUpView() {
  const router = useRouter();

  const [showPassword, setShowPassword] = useState(false);
  const [gender, setGender] = useState('female');

  const [avatar, setAvatar] = useState<string>();
  const inputRef = useRef<HTMLInputElement>(null);

  const nameRef = useRef();
  const phoneRef = useRef();
  const ageRef = useRef();
  const fbRef = useRef();
  const instaRef = useRef();
  const tweetRef = useRef();
  const imdbRef = useRef();
  const emailRef = useRef();
  const passwordRef = useRef();

  const handleClick = () => {
    if (inputRef.current) {
      inputRef.current.click();
    }
  };

  const handleImageChange = (event: ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files[0]) {
      setAvatar(URL.createObjectURL(event.target.files[0]));
    }
  };

  const handleGenderChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setGender((event.target as HTMLInputElement).value);
  };

  const showRefContent = async () => {
    if (
      gender &&
      avatar &&
      nameRef?.current &&
      phoneRef?.current &&
      ageRef?.current &&
      emailRef?.current &&
      passwordRef?.current
    ) {
      const name = (nameRef?.current as { value: string }).value;
      const phone = +(phoneRef?.current as { value: number }).value;
      const age = +(ageRef?.current as { value: number }).value;
      const email = (emailRef?.current as { value: string }).value;
      const password = (passwordRef?.current as { value: string }).value;

      let credentials: SignUpCredentials = {
        avatar,
        name,
        phone,
        age,
        gender,
        email,
        password,
      };

      if (fbRef?.current && instaRef?.current && tweetRef?.current && imdbRef?.current) {
        const facebookId = (fbRef?.current as { value: string }).value;
        const instagramId = (instaRef?.current as { value: string }).value;
        const tweeterId = (tweetRef?.current as { value: string }).value;
        const imdbId = (imdbRef?.current as { value: string }).value;
        credentials = { ...credentials, facebookId, instagramId, tweeterId, imdbId };
      }

      console.log(credentials);

      const response = await postSignup(credentials);

      console.log(response);

      if (response.success) {
        toast.success('SignUp successful!');
        router.push('/login');
      } else {
        toast.error('Invalid username or password');
      }
    }
  };

  const renderForm = (
    <Box display="flex" flexDirection="column" alignItems="flex-end">
      <ToastContainer />
      
      <Stack
        width="100%"
        display="flex"
        direction="column"
        alignItems="center"
        spacing={2}
        sx={{ mb: 3 }}
      >
        <Avatar
          sx={{ width: 100, height: 100, cursor: 'pointer', border: '3px solid black' }}
          src={avatar}
          onClick={handleClick}
        />
        <input type="file" accept="image/*" onChange={handleImageChange} ref={inputRef} hidden />
      </Stack>

      <TextField
        fullWidth
        name="name"
        label="Name"
        inputRef={nameRef}
        defaultValue="Mayank Singh"
        InputLabelProps={{ shrink: true }}
        sx={{ mb: 3 }}
      />

      <TextField
        fullWidth
        name="phoneNumber"
        label="Phone Number"
        type="tel"
        inputRef={phoneRef}
        inputProps={{
          minLength: 10,
          maxLength: 10,
        }}
        maxRows={10}
        defaultValue="9876543210"
        InputLabelProps={{ shrink: true }}
        sx={{ mb: 3 }}
      />

      <TextField
        fullWidth
        name="age"
        label="Age"
        type="number"
        inputRef={ageRef}
        defaultValue="23"
        InputLabelProps={{ shrink: true }}
        sx={{ mb: 3 }}
      />

      <FormControl sx={{ mb: 3 }} fullWidth>
        <FormLabel id="demo-controlled-gender">Gender</FormLabel>
        <RadioGroup
          row
          aria-labelledby="demo-controlled-gender"
          name="controlled-gender"
          value={gender}
          onChange={handleGenderChange}
        >
          <FormControlLabel value="female" control={<Radio />} label="Female" />
          <FormControlLabel value="male" control={<Radio />} label="Male" />
        </RadioGroup>
      </FormControl>

      <Box
        display="flex"
        flexDirection="row"
        justifyContent="space-between"
        width="100%"
        gap="20px"
      >
        <TextField
          fullWidth
          name="facebookId"
          label="Facebook ID"
          defaultValue="hello@gmail.com"
          inputRef={fbRef}
          InputLabelProps={{ shrink: true }}
          sx={{ mb: 3 }}
        />

        <TextField
          fullWidth
          name="instagramId"
          label="Instagram ID"
          inputRef={instaRef}
          defaultValue="hello@gmail.com"
          InputLabelProps={{ shrink: true }}
          sx={{ mb: 3 }}
        />
      </Box>
      <Box
        display="flex"
        flexDirection="row"
        justifyContent="space-between"
        width="100%"
        gap="20px"
      >
        <TextField
          fullWidth
          name="twitterId"
          label="Twitter ID"
          inputRef={tweetRef}
          defaultValue="hello@gmail.com"
          InputLabelProps={{ shrink: true }}
          sx={{ mb: 3 }}
        />
        <TextField
          fullWidth
          name="imdbId"
          label="Imdb ID"
          inputRef={imdbRef}
          defaultValue="hello@gmail.com"
          InputLabelProps={{ shrink: true }}
          sx={{ mb: 3 }}
        />
      </Box>

      <TextField
        fullWidth
        name="email"
        label="Email address"
        inputRef={emailRef}
        defaultValue="hello@gmail.com"
        InputLabelProps={{ shrink: true }}
        sx={{ mb: 3 }}
      />

      <Link
        component={RouterLink}
        href="/forgot-password"
        variant="body2"
        color="inherit"
        sx={{ mb: 1.5 }}
      >
        Forgot password?
      </Link>

      <TextField
        fullWidth
        name="password"
        label="Password"
        defaultValue="demo@1234"
        inputRef={passwordRef}
        InputLabelProps={{ shrink: true }}
        type={showPassword ? 'text' : 'password'}
        InputProps={{
          endAdornment: (
            <InputAdornment position="end">
              <IconButton onClick={() => setShowPassword(!showPassword)} edge="end">
                <Iconify icon={showPassword ? 'solar:eye-bold' : 'solar:eye-closed-bold'} />
              </IconButton>
            </InputAdornment>
          ),
        }}
        sx={{ mb: 3 }}
      />

      <LoadingButton
        fullWidth
        size="large"
        type="submit"
        color="inherit"
        variant="contained"
        onClick={showRefContent}
      >
        Sign up
      </LoadingButton>
    </Box>
  );

  return (
    <>
      <Box gap={1.5} display="flex" flexDirection="column" alignItems="center" sx={{ mb: 5 }}>
        <Typography variant="h5">Sign up</Typography>
      </Box>

      {renderForm}

      <Divider sx={{ my: 3, '&::before, &::after': { borderTopStyle: 'dashed' } }}>
        <Typography
          variant="overline"
          sx={{ color: 'text.secondary', fontWeight: 'fontWeightMedium' }}
        >
          OR
        </Typography>
      </Divider>

      <Box gap={1} display="flex" justifyContent="center">
        <IconButton color="inherit">
          <Iconify icon="logos:google-icon" />
        </IconButton>
        <IconButton color="inherit">
          <Iconify icon="eva:github-fill" />
        </IconButton>
        <IconButton color="inherit">
          <Iconify icon="ri:twitter-x-fill" />
        </IconButton>
      </Box>
    </>
  );
}
