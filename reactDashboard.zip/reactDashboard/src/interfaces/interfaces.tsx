export interface VideoData {
  title: string;
  overview: string;
  posterPath: string; // Thumbnail
  videoUrl: string; // actual video
  language: string;
  genres: string[];

  releaseDate: string;
  runtime: number;
  creatorId: number;
  
  images: { height: number; width: number; filePath: string }[];
  shorts: { name: string; shortKey: string; type: string }[];
  cast: {
    name: string;
    profilePath: string | null;
    characterr: string;
    popularity: number;
  }[];
}



export interface NewCastProps {
  name: string;
  character: string;
  popularity: number;
  profilePath: string | null;
}