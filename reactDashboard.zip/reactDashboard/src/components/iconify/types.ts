import type { IconProps } from '@iconify/react';
import type { BoxProps } from '@mui/material/Box';

// ----------------------------------------------------------------------

export type IconifyProps = BoxProps & IconProps;
