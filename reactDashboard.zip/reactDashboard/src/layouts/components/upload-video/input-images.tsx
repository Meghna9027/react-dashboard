import { Box, Button, Grid, IconButton, ImageList, ImageListItem } from '@mui/material';
import React, { useState, Dispatch, SetStateAction } from 'react';
import { Icon } from '@iconify/react';
import { VideoData } from 'src/interfaces/interfaces';
import useCloudinaryUpload from 'src/hooks/useCloudinaryUpload';
// import cancelIcon from '@iconify/icons-mdi/close-circle';

interface InputDetailsProps {
  multiple: boolean;
  images: File[];
  setImages: Dispatch<SetStateAction<File[]>>;
}

export default function InputImages({ multiple = true, images, setImages }: InputDetailsProps) {
  const handleOnAddImage = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return;
    const files = Array.from(e.target.files);
    setImages((prevImages) => [...prevImages, ...files]);
    e.target.value = '';
  };

  const handleOnRemoveImage = (index: number) => {
    setImages((prevImages) => prevImages.filter((_, i) => i !== index));
  };

  return (
    <>
      <Box sx={{ overflowY: 'scroll' }}>
        <ImageList variant="masonry" cols={3} gap={8}>
          {images.map((item, index) => (
            <ImageListItem key={index}>
              <IconButton
                aria-label="delete image"
                style={{ position: 'absolute', top: 10, right: 10, color: 'black' }}
                onClick={() => handleOnRemoveImage(index)}
              >
                X
              </IconButton>
              <img
                src={URL.createObjectURL(item)}
                alt={`image-${index}`}
                style={{ objectFit: 'contain' }}
                loading="lazy"
              />
            </ImageListItem>
          ))}
        </ImageList>
      </Box>
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          width: '100%',
          height: images.length === 0 ? '100%' : 'auto', // If no images, center the button
        }}
      >
        <label htmlFor="upload-button">
          <Button variant="contained" component="span" style={{ marginTop: 16 }}>
            + Add Images
          </Button>
        </label>
      </Box>

      <input
        id="upload-button"
        type="file"
        multiple={multiple}
        accept="image/*"
        onChange={handleOnAddImage}
        style={{ display: 'none' }}
      />
    </>
  );
}
