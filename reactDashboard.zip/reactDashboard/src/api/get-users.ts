import React from 'react'

export default function getUsers() {
  return null;
}
