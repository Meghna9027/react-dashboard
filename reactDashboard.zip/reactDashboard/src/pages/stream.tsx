import { Helmet } from 'react-helmet-async';

import { CONFIG } from 'src/config-global';

import { StreamView } from 'src/sections/stream/view';

export default function Page() {
  return (
    <>
      <Helmet>
        <title> {`Stream - ${CONFIG.appName}`}</title>
      </Helmet>

      <StreamView />
    </>
  );
}
