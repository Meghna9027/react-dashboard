import React, { useRef, useMemo, useEffect } from 'react';
import { ZegoUIKitPrebuilt } from '@zegocloud/zego-uikit-prebuilt';

function randomID(len: number): string {
  const chars = '12345qwertyuiopasdfgh67890jklmnbvcxzMNBVCZXASDQWERTYHGFUIOLKJP';
  const maxPos = chars.length;
  let result = '';
  if (result) return result;
  len = len || 5;
  for (let i = 0; i < len; i += 1) {
    result += chars.charAt(Math.floor(Math.random() * maxPos));
  }
  return result;
}

export function getUrlParams(url = window.location.href) {
  const urlStr = url.split('?')[1];
  return new URLSearchParams(urlStr);
}

// interface SharedLink {
//   name?: string;
//   url?: string;
// }

export function StreamView() {
  const roomID = getUrlParams().get('roomID') || randomID(5);
  const role_str = getUrlParams(window.location.href).get('role') || 'Host';
  const role =
    role_str === 'Host'
      ? ZegoUIKitPrebuilt.Host
      : role_str === 'Cohost'
        ? ZegoUIKitPrebuilt.Cohost
        : ZegoUIKitPrebuilt.Audience;

  const sharedLinks = useMemo(() => {
    const links = [];
    if (role === ZegoUIKitPrebuilt.Host || role === ZegoUIKitPrebuilt.Cohost) {
      links.push({
        name: 'Join as co-host',
        url: `${window.location.protocol}//${window.location.host}${window.location.pathname}?roomID=${roomID}&role=Cohost`,
      });
    }
    links.push({
      name: 'Join as audience',
      url: `${window.location.protocol}//${window.location.host}${window.location.pathname}?roomID=${roomID}&role=Audience`,
    });
    return links;
  }, [role, roomID]);

  // const sharedLinks: SharedLink[] = [];
  // if (role === ZegoUIKitPrebuilt.Host || role === ZegoUIKitPrebuilt.Cohost) {
  //   sharedLinks.push({
  //     name: 'Join as co-host',
  //     url: `${window.location.protocol}//${window.location.host}${window.location.pathname}?roomID=${roomID}&role=Cohost`,
  //   });
  // }
  // sharedLinks.push({
  //   name: 'Join as audience',
  //   url: `${window.location.protocol}//${window.location.host}${window.location.pathname}?roomID=${roomID}&role=Audience`,
  // });

  const appID = 2113943036;
  const serverSecret = '0df3189c360967e9598ead9c0fd9cb02';
  const kitToken = ZegoUIKitPrebuilt.generateKitTokenForTest(
    appID,
    serverSecret,
    roomID,
    randomID(5),
    randomID(5)
  );

  const myMeeting = useRef(null);

  useEffect(() => {
    if (myMeeting.current) {
      const zp = ZegoUIKitPrebuilt.create(kitToken);
      zp.joinRoom({
        container: myMeeting.current,
        scenario: {
          mode: ZegoUIKitPrebuilt.LiveStreaming,
          config: {
            role,
          },
        },
        sharedLinks,
      });
    }
  }, [kitToken, role, sharedLinks]);

  return (
    <div className="myCallContainer" ref={myMeeting} style={{ width: '100%', height: '100%' }} />
  );
}
