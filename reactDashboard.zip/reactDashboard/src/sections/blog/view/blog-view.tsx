import { useState, useCallback, useEffect } from 'react';

import { Box } from '@mui/material';
import { Modal } from '@mui/material';
import Button from '@mui/material/Button';
import Grid from '@mui/material/Unstable_Grid2';
import Typography from '@mui/material/Typography';
import Pagination from '@mui/material/Pagination';
import { _posts, _postTitles } from 'src/_mock';
import { DashboardContent } from 'src/layouts/dashboard';
import { Iconify } from 'src/components/iconify';
import { PostItem } from '../post-item';
import { PostSort } from '../post-sort';
import { PostSearch } from '../post-search';
import VideoUploadForm from 'src/layouts/components/video-upload-form';
import { mediaQueries } from 'src/theme/styles';
import { getVideos } from 'src/api/get-videos';
import { toast, ToastContainer } from 'react-toastify';
import { jwtDecode, JwtPayload } from 'jwt-decode';
import VideoDetailPage from 'src/layouts/components/video-detail-page';

interface CustomJwtPayload extends JwtPayload {
  id: number;
}

const videoData = [
  {
    id: 1,
    title: 'Video 1',
    url: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    description: 'This is the description for Video 1.',
    cast: 'This is the cast for Video 1.',
    comments: [
      {
        userName: 'John Doe',
        profilePic: 'https://via.placeholder.com/40', // Placeholder image
        comment: 'This video is amazing! Thanks for sharing.',
      },
      {
        userName: 'Jane Smith',
        profilePic: 'https://via.placeholder.com/40',
        comment: 'Great explanation, very clear and concise.',
      },
    ],
  },
  {
    id: 2,
    title: 'Video 2',
    url: 'https://www.youtube.com/embed/9bZkp7q19f0',
    description: 'This is the description for Video 2.',
    cast: 'This is the cast for Video 2.',
    comments: [
      {
        userName: 'Alice Johnson',
        profilePic: 'https://via.placeholder.com/40',
        comment: 'This was really helpful, thank you!',
      },
    ],
  },
  {
    id: 3,
    title: 'Video 3',
    url: 'https://www.youtube.com/embed/tgbNymZ7vqY',
    description: 'This is the description for Video 3.',
    cast: 'This is the cast for Video 3.',
    comments: [
      {
        userName: 'John Doe',
        profilePic: 'https://via.placeholder.com/40', // Placeholder image
        comment: 'This video is amazing! Thanks for sharing.',
      },
      {
        userName: 'Jane Smith',
        profilePic: 'https://via.placeholder.com/40',
        comment: 'Great explanation, very clear and concise.',
      },
    ],
  },
  {
    id: 4,
    title: 'Video 3',
    url: 'https://www.youtube.com/embed/uiOimjucxow',
    description: 'This is the description for Video 4.',
    cast: 'This is the cast for Video 4.',
    comments: [
      {
        userName: 'Alice Johnson',
        profilePic: 'https://via.placeholder.com/40',
        comment: 'This was really helpful, thank you!',
      },
    ],
  },
  {
    id: 5,
    title: 'Video 3',
    url: 'https://www.youtube.com/embed/EMOEjA6UMsQ',
    description: 'This is the description for Video 5.',
    cast: 'This is the cast for Video 5.',
    comments: [
      {
        userName: 'John Doe',
        profilePic: 'https://via.placeholder.com/40', // Placeholder image
        comment: 'This video is amazing! Thanks for sharing.',
      },
      {
        userName: 'Jane Smith',
        profilePic: 'https://via.placeholder.com/40',
        comment: 'Great explanation, very clear and concise.',
      },
    ],
  },
  {
    id: 6,
    title: 'Video 3',
    url: 'https://www.youtube.com/embed/Ua5AW2czRAE',
    description: 'This is the description for Video 6.',
    cast: 'This is the cast for Video 6.',
    comments: [
      {
        userName: 'Alice Johnson',
        profilePic: 'https://via.placeholder.com/40',
        comment: 'This was really helpful, thank you!',
      },
    ],
  },
  {
    id: 7,
    title: 'Video 3',
    url: 'https://www.youtube.com/embed/WKbwopSXLWU',
    description: 'This is the description for Video 7.',
    cast: 'This is the cast for Video 7.',
    comments: [
      {
        userName: 'John Doe',
        profilePic: 'https://via.placeholder.com/40', // Placeholder image
        comment: 'This video is amazing! Thanks for sharing.',
      },
      {
        userName: 'Jane Smith',
        profilePic: 'https://via.placeholder.com/40',
        comment: 'Great explanation, very clear and concise.',
      },
    ],
  },
  {
    id: 8,
    title: 'Video 3',
    url: 'https://www.youtube.com/embed/0YFENcrtc7M',
    description: 'This is the description for Video 8.',
    cast: 'This is the cast for Video 8.',
    comments: [
      {
        userName: 'Alice Johnson',
        profilePic: 'https://via.placeholder.com/40',
        comment: 'This was really helpful, thank you!',
      },
    ],
  },
  {
    id: 9,
    title: 'Video 3',
    url: 'https://www.youtube.com/embed/Q8bKKn8gBVY',
    description: 'This is the description for Video 9.',
    cast: 'This is the cast for Video 9.',
    comments: [
      {
        userName: 'John Doe',
        profilePic: 'https://via.placeholder.com/40', // Placeholder image
        comment: 'This video is amazing! Thanks for sharing.',
      },
      {
        userName: 'Jane Smith',
        profilePic: 'https://via.placeholder.com/40',
        comment: 'Great explanation, very clear and concise.',
      },
    ],
  },
  {
    id: 10,
    title: 'Video 3',
    url: 'https://www.youtube.com/embed/U_UjsT_RkI8',
    description: 'This is the description for Video 10.',
    cast: 'This is the cast for Video 10.',
    comments: [
      {
        userName: 'Alice Johnson',
        profilePic: 'https://via.placeholder.com/40',
        comment: 'This was really helpful, thank you!',
      },
    ],
  },
  {
    id: 11,
    title: 'Video 3',
    url: 'https://www.youtube.com/embed/kzTWRX9Dhrg',
    description: 'This is the description for Video 11.',
    cast: 'This is the cast for Video 11.',
    comments: [
      {
        userName: 'John Doe',
        profilePic: 'https://via.placeholder.com/40', // Placeholder image
        comment: 'This video is amazing! Thanks for sharing.',
      },
      {
        userName: 'Jane Smith',
        profilePic: 'https://via.placeholder.com/40',
        comment: 'Great explanation, very clear and concise.',
      },
    ],
  },
  {
    id: 12,
    title: 'Video 3',
    url: 'https://www.youtube.com/embed/bBvlfHU4nDI',
    description: 'This is the description for Video 12.',
    cast: 'This is the cast for Video 12.',
    comments: [
      {
        userName: 'Alice Johnson',
        profilePic: 'https://via.placeholder.com/40',
        comment: 'This was really helpful, thank you!',
      },
    ],
  },
  {
    id: 13,
    title: 'Video 3',
    url: 'https://www.youtube.com/embed/DIJW7rWPkSw',
    description: 'This is the description for Video 13.',
    cast: 'This is the cast for Video 13.',
    comments: [
      {
        userName: 'John Doe',
        profilePic: 'https://via.placeholder.com/40', // Placeholder image
        comment: 'This video is amazing! Thanks for sharing.',
      },
      {
        userName: 'Jane Smith',
        profilePic: 'https://via.placeholder.com/40',
        comment: 'Great explanation, very clear and concise.',
      },
    ],
  },
  {
    id: 14,
    title: 'Video 3',
    url: 'https://www.youtube.com/embed/6WLugDJYXmM',
    description: 'This is the description for Video 14.',
    cast: 'This is the cast for Video 14.',
    comments: [
      {
        userName: 'Alice Johnson',
        profilePic: 'https://via.placeholder.com/40',
        comment: 'This was really helpful, thank you!',
      },
    ],
  },
  {
    id: 15,
    title: 'Video 3',
    url: 'https://www.youtube.com/embed/0KozfDYK1EU',
    description: 'This is the description for Video 15.',
    cast: 'This is the cast for Video 15.',
    comments: [
      {
        userName: 'John Doe',
        profilePic: 'https://via.placeholder.com/40', // Placeholder image
        comment: 'This video is amazing! Thanks for sharing.',
      },
      {
        userName: 'Jane Smith',
        profilePic: 'https://via.placeholder.com/40',
        comment: 'Great explanation, very clear and concise.',
      },
    ],
  },
  {
    id: 16,
    title: 'Video 3',
    url: 'https://www.youtube.com/embed/osbSJ2Fr1nE',
    description: 'This is the description for Video 16.',
    cast: 'This is the cast for Video 16.',
    comments: [
      {
        userName: 'Alice Johnson',
        profilePic: 'https://via.placeholder.com/40',
        comment: 'This was really helpful, thank you!',
      },
    ],
  },
  {
    id: 17,
    title: 'Video 3',
    url: 'https://www.youtube.com/embed/XgdY_s1LsZc',
    description: 'This is the description for Video 17.',
    cast: 'This is the cast for Video 17.',
    comments: [
      {
        userName: 'John Doe',
        profilePic: 'https://via.placeholder.com/40', // Placeholder image
        comment: 'This video is amazing! Thanks for sharing.',
      },
      {
        userName: 'Jane Smith',
        profilePic: 'https://via.placeholder.com/40',
        comment: 'Great explanation, very clear and concise.',
      },
    ],
  },
  {
    id: 18,
    title: 'Video 3',
    url: 'https://www.youtube.com/embed/36oG0GKlVBs',
    description: 'This is the description for Video 18.',
    cast: 'This is the cast for Video 18.',
    comments: [
      {
        userName: 'Alice Johnson',
        profilePic: 'https://via.placeholder.com/40',
        comment: 'This was really helpful, thank you!',
      },
    ],
  },
  {
    id: 19,
    title: 'Video 3',
    url: 'https://www.youtube.com/embed/cN1ouN1N70w',
    description: 'This is the description for Video 19.',
    cast: 'This is the cast for Video 19.',
    comments: [
      {
        userName: 'John Doe',
        profilePic: 'https://via.placeholder.com/40', // Placeholder image
        comment: 'This video is amazing! Thanks for sharing.',
      },
      {
        userName: 'Jane Smith',
        profilePic: 'https://via.placeholder.com/40',
        comment: 'Great explanation, very clear and concise.',
      },
    ],
  },
  {
    id: 20,
    title: 'Video 3',
    url: 'https://www.youtube.com/embed/ninsb8n8cRE',
    description: 'This is the description for Video 20.',
    cast: 'This is the cast for Video 20.',
    comments: [
      {
        userName: 'Alice Johnson',
        profilePic: 'https://via.placeholder.com/40',
        comment: 'This was really helpful, thank you!',
      },
    ],
  },
  {
    id: 21,
    title: 'Video 3',
    url: 'https://www.youtube.com/embed/IKEdWz8Y27I',
    description: 'This is the description for Video 21.',
    cast: 'This is the cast for Video 21.',
    comments: [
      {
        userName: 'John Doe',
        profilePic: 'https://via.placeholder.com/40', // Placeholder image
        comment: 'This video is amazing! Thanks for sharing.',
      },
      {
        userName: 'Jane Smith',
        profilePic: 'https://via.placeholder.com/40',
        comment: 'Great explanation, very clear and concise.',
      },
    ],
  },
  {
    id: 22,
    title: 'Video 3',
    url: 'https://www.youtube.com/embed/o1tIvfplhHc',
    description: 'This is the description for Video 22.',
    cast: 'This is the cast for Video 22.',
    comments: [
      {
        userName: 'Alice Johnson',
        profilePic: 'https://via.placeholder.com/40',
        comment: 'This was really helpful, thank you!',
      },
    ],
  },
  {
    id: 23,
    title: 'Video 3',
    url: 'https://www.youtube.com/embed/7k5gM4ClRRo',
    description: 'This is the description for Video 23.',
    cast: 'This is the cast for Video 23.',
    comments: [
      {
        userName: 'John Doe',
        profilePic: 'https://via.placeholder.com/40', // Placeholder image
        comment: 'This video is amazing! Thanks for sharing.',
      },
      {
        userName: 'Jane Smith',
        profilePic: 'https://via.placeholder.com/40',
        comment: 'Great explanation, very clear and concise.',
      },
    ],
  },
];

const modalStyle = (theme: any) => ({
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: '80%',
  bgcolor: 'background.paper',
  border: '20px solid #fff',
  borderRadius: '20px',
  boxShadow: 24,
  // p: 4,
  maxHeight: 'calc(100vh - 100px)', // Set max height for modal content
  overflowY: 'auto', // Enable scroll for content exceeding max height
  [theme.breakpoints.up('md')]: {
    width: '50%', // Adjust width for larger screens
  },
  '&::-webkit-scrollbar': {
    display: 'none',
  },
});

export function BlogView() {
  const [sortBy, setSortBy] = useState('latest');
  const [openModal, setOpenModal] = useState(false);
  const [openVidoeModal, setOpenVideoModal] = useState(false);
  const [selectedVideo, setSelectedVideo] = useState<string | null>(null); // Add selectedVideo state
  const [selectedPostDescription, setSelectedPostDescription] = useState<string | null>(null);
  const [selectedPostTitle, setSelectedPostTitle] = useState<string | null>(null);
  const [selectedPostCast, setSelectedPostCast] = useState<string | null>(null);
  const [selectedPostComment, setSelectedPostComment] = useState<
    { userName: string; profilePic: string; comment: string }[]
  >([]);
  const [selectedPostIndex, setSelectedPostIndex] = useState<number | null>(null); // Track the clicked post index

  const handleSort = useCallback((newSort: string) => {
    setSortBy(newSort);
  }, []);

  useEffect(() => {
    fetchVideos();
  }, []);

  const fetchVideos = async () => {
    const token = localStorage.getItem('authToken');
    if (token) {
      const authObj = jwtDecode<CustomJwtPayload>(token);

      console.log(authObj, token);

      if (authObj.id) {
        const response = await getVideos(+authObj.id);

        if (response.success) {
          toast.success("'Video Fetch successful!");
        } else {
          toast.error('Invalid id');
        }
      }
    }
  };

  const handlePostClick = (index: number) => {
    setSelectedPostIndex(index); // Set the clicked post index
    setSelectedVideo(videoData[index]?.url || null); // Set the corresponding video URL
    setSelectedPostTitle(_posts[index]?.title || '');
    setOpenVideoModal(true); // Open the video modal
    setSelectedPostDescription(videoData[index]?.description || ''); // Set the corresponding video description
    setSelectedPostCast(videoData[index]?.cast || '');
    setSelectedPostComment(videoData[index]?.comments || []);
  };

  return (
    <DashboardContent>
      <ToastContainer />
      <Box display="flex" alignItems="center" mb={5}>
        <Typography variant="h4" flexGrow={1}>
          Videos
        </Typography>
        <Button
          variant="contained"
          color="inherit"
          startIcon={<Iconify icon="mingcute:add-line" />}
          onClick={() => {
            setOpenModal(true);
          }}
        >
          New Video
        </Button>
      </Box>
      <Modal
        open={openModal}
        onClose={() => {
          setOpenModal(false);
        }}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={modalStyle}>
          <VideoUploadForm />
        </Box>
      </Modal>

      {/* implement search & sort */}
      <Box display="flex" alignItems="center" justifyContent="space-between" sx={{ mb: 5 }}>
        <PostSearch posts={_posts} />
        <PostSort
          sortBy={sortBy}
          onSort={handleSort}
          options={[
            { value: 'latest', label: 'Latest' },
            { value: 'popular', label: 'Popular' },
            { value: 'oldest', label: 'Oldest' },
          ]}
        />
      </Box>

      <Grid container spacing={3}>
        {_posts.map((post, index) => {
          const latestPostLarge = index === 0;
          const latestPost = index === 1 || index === 2;

          return (
            <Grid
              key={post.id}
              xs={12}
              sm={latestPostLarge ? 12 : 6}
              md={latestPostLarge ? 6 : 3}
              onClick={() => handlePostClick(index)} // Trigger post click
              style={{ cursor: 'pointer' }}
              // component="div"
            >
              <PostItem post={post} latestPost={latestPost} latestPostLarge={latestPostLarge} />
            </Grid>
          );
        })}
      </Grid>
      <Modal
        open={openVidoeModal}
        onClose={() => {
          setOpenVideoModal(false);
        }}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={modalStyle}>
          <VideoDetailPage
            videoUrl={selectedVideo}
            videoTitle={selectedPostTitle || ''}
            videoDescription={selectedPostDescription || ''}
            videoCast={selectedPostCast || ''}
            comments={selectedPostComment}
          />
        </Box>
      </Modal>

      <Pagination count={10} color="primary" sx={{ mt: 8, mx: 'auto' }} />
    </DashboardContent>
  );
}
