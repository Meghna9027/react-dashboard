import React from 'react'
import { useAuth } from './AuthProvider';
import { Navigate, Route } from 'react-router-dom';

interface PrivateRouteProps {
    element: React.ReactElement;
    path: string;
  }
  
  const PrivateRoute = ({ element, path }: PrivateRouteProps) => {
    const { isAuthenticated } = useAuth();
    return isAuthenticated ? element : <Navigate to="/login" replace />;
  };
  
  export default PrivateRoute;
