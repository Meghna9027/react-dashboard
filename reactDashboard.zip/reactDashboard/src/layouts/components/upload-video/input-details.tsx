import { Avatar, Button, Chip, MenuItem, Stack } from '@mui/material';
import {
  Box,
  FormControl,
  InputLabel,
  OutlinedInput,
  Select,
  SelectChangeEvent,
  TextField,
} from '@mui/material';
import React, { ChangeEvent, Dispatch, SetStateAction, useEffect, useRef, useState } from 'react';
import { toast } from 'react-toastify';
import { VideoData } from 'src/interfaces/interfaces';

interface InputDetailsProps {
  thumbnail: File[];
  setThumbnail: Dispatch<SetStateAction<File[]>>;
  video: File[];
  setVideo: Dispatch<SetStateAction<File[]>>;
  videoDetails: VideoData;
  setVideoDetails: Dispatch<SetStateAction<VideoData>>;
}

const names = ['ACTION', 'COMEDY', 'DRAMA', 'THRILL', 'HORROR'];

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};

export default function InputDetails({
  thumbnail,
  setThumbnail,
  video,
  setVideo,
  videoDetails,
  setVideoDetails,
  setIsNextDisabled,
}: InputDetailsProps & { setIsNextDisabled: Dispatch<SetStateAction<boolean>> }) {
  const [genres, setGenres] = useState<string[]>(videoDetails?.genres || []);
  const [startVideo, setStartVideo] = useState<boolean>(false);

  const inputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    // Check if all required fields are filled
    const isDisabled =
      !thumbnail.length || // Check if thumbnail is uploaded
      // !video.length || // Check if video is uploaded
      !videoDetails?.title || // Check if title is filled
      !videoDetails?.overview || // Check if overview is filled
      !videoDetails?.genres?.length || // Check if genres are selected
      !videoDetails?.language; // Check if language is filled

    setIsNextDisabled(isDisabled); // Update the "Next" button state
  }, [thumbnail, video, videoDetails, setIsNextDisabled]);

  const handleChange = (event: SelectChangeEvent<string[]>) => {
    const {
      target: { value },
    } = event;
    setGenres(typeof value === 'string' ? value.split(',') : value);
    setVideoDetails((p) => {
      return { ...p, genres: typeof value === 'string' ? value.split(',') : value };
    });
  };

  const handleClick = () => {
    // if (thumbnail) {
    //   setThumbnail([]);
    // } else {
    if (inputRef.current) {
      inputRef.current.click();
    }
    // }
  };

  const handleImageChange = (event: ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files[0]) {
      const files = Array.from(event.target.files);
      setThumbnail([...files]);
    }
  };

  const handleOnAddVideo = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files[0]) {
      const files = Array.from(event.target.files);
      setVideo([...files]);
    }
    event.target.value = '';
  };

  const handleMouseEnter = () => {
    setStartVideo(true);
    if (videoRef.current) {
      videoRef.current.play();
    }
  };

  const handleMouseLeave = () => {
    setStartVideo(false);
    if (videoRef.current) {
      videoRef.current.pause();

      videoRef.current.currentTime = 0;
    }
  };

  return (
    <div>
      <Box display="flex" flexDirection="column" alignItems="flex-start">
        <Stack
          width="100%"
          display="flex"
          direction="column"
          alignItems="center"
          spacing={2}
          sx={{ mb: 3 }}
        >
          <Box
            height={'200px'}
            width={'100%'}
            alignContent={'center'}
            textAlign={'center'}
            border={`2px solid ${thumbnail.length != 0 ? 'black' : 'red'}`}
            borderRadius={'20px'}
            onClick={handleClick}
            onMouseEnter={handleMouseEnter}
            onMouseLeave={handleMouseLeave}
            style={{ cursor: 'pointer' }}
          >
            {startVideo && video.length != 0 ? (
              <video
                src={URL.createObjectURL(video[0])}
                controls
                ref={videoRef}
                style={{ width: '100%', height: '100%', objectFit: 'contain' }}
              />
            ) : (
              thumbnail.length != 0 && (
                <img
                  height={'100%'}
                  src={URL.createObjectURL(thumbnail[0])}
                  alt={`image-thumbnail`}
                  // style={{ objectFit: 'contain' }}
                  loading="lazy"
                />
              )
            )}
            {thumbnail.length == 0 && !startVideo && <h3>Upload Thumbnail</h3>}
          </Box>
          <input type="file" accept="image/*" onChange={handleImageChange} ref={inputRef} hidden />
        </Stack>

        <label htmlFor="upload-button">
          <Button
            variant="contained"
            component="span"
            // style={{ marginTop: 16 }}
            disabled={thumbnail.length == 0}
            sx={{ mb: 3 }}
          >
            Upload
          </Button>
        </label>
        <input
          id="upload-button"
          type="file"
          multiple
          accept="video/*"
          disabled={thumbnail.length == 0}
          onChange={handleOnAddVideo}
          style={{ display: 'none' }}
        />

        <TextField
          fullWidth
          error={videoDetails?.title == ''}
          name="title"
          label="Title"
          defaultValue={videoDetails?.title}
          InputLabelProps={{ shrink: true }}
          onChange={(e) => {
            setVideoDetails((p) => {
              return { ...p, title: e.target.value };
            });
          }}
          sx={{ mb: 3 }}
        />

        <TextField
          fullWidth
          name="overview"
          label="Overview"
          multiline
          rows={4}
          error={videoDetails?.overview == ''}
          id={videoDetails?.overview == '' ? 'outlined-error-helper-text' : ''}
          helperText={videoDetails?.overview == '' && 'Incorrect entry.'}
          inputProps={{
            minLength: 10,
            maxLength: 10,
          }}
          onChange={(e) => {
            setVideoDetails((p) => {
              return { ...p, overview: e.target.value };
            });
          }}
          defaultValue={videoDetails?.overview || ''}
          InputLabelProps={{ shrink: true }}
          sx={{ mb: 3 }}
        />

        <FormControl sx={{ mb: 3, width: '100%' }} error={videoDetails?.genres?.length == 0}>
          <InputLabel id="demo-multiple-chip-label">Genres</InputLabel>
          <Select
            labelId="demo-multiple-chip-label"
            id="demo-multiple-chip"
            multiple
            value={genres || videoDetails?.genres}
            defaultValue={videoDetails?.genres}
            onChange={handleChange}
            input={<OutlinedInput id="select-multiple-chip" label="Chip" />}
            renderValue={(selected) => {
              // console.log(selected);
              return (
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                  {selected.map((value) => (
                    <Chip key={value} label={value} />
                  ))}
                </Box>
              );
            }}
            MenuProps={MenuProps}
          >
            {names.map((name) => (
              <MenuItem key={name} value={name}>
                {name}
              </MenuItem>
            ))}
          </Select>
        </FormControl>

        <TextField
          fullWidth
          name="language"
          label="Language"
          error={videoDetails?.language == ''}
          id={videoDetails?.language == '' ? 'outlined-error-helper-text' : ''}
          helperText={videoDetails?.language == '' && 'Incorrect entry.'}
          defaultValue={videoDetails?.language}
          onChange={(e) => {
            setVideoDetails((p) => {
              return { ...p, language: e.target.value };
            });
          }}
          InputLabelProps={{ shrink: true }}
          sx={{ mb: 3 }}
        />
      </Box>
    </div>
  );
}
